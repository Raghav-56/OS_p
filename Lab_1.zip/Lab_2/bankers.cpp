// Bankers algorithm in cpp
