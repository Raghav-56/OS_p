// Producer Consumer algorithm in cpp

#include <iostream>
using namespace std;

const int BUFFER_SIZE = 5;

// Simple pseudo-random number generator
class SimpleRandom
{
private:
    unsigned int seed;

public:
    SimpleRandom(unsigned int initial = 12345) : seed(initial) {}

    int next(int min, int max)
    {
        seed = (seed * 1103515245 + 12345) % 2147483647;
        return min + (seed % (max - min + 1));
    }
};

// Custom circular buffer implementation
class CircularBuffer
{
private:
    int buffer[BUFFER_SIZE];
    int head = 0;
    int tail = 0;
    int count = 0;

public:
    bool isEmpty() const
    {
        return count == 0;
    }

    bool isFull() const
    {
        return count == BUFFER_SIZE;
    }

    void push(int item)
    {
        if (!isFull())
        {
            buffer[tail] = item;
            tail = (tail + 1) % BUFFER_SIZE;
            count++;
        }
    }

    int front() const
    {
        return buffer[head];
    }

    void pop()
    {
        if (!isEmpty())
        {
            head = (head + 1) % BUFFER_SIZE;
            count--;
        }
    }

    int size() const
    {
        return count;
    }
};

// Buffer class for producer-consumer
class Buffer
{
private:
    CircularBuffer buffer;
    bool producing = true; // Flag to alternate between producer and consumer

public:
    bool produce(int item)
    {
        if (buffer.isFull())
        {
            cout << "Buffer is full. Producer waiting..." << endl;
            return false;
        }

        buffer.push(item);
        cout << "Produced: " << item << " (Buffer size: " << buffer.size() << ")" << endl;
        return true;
    }

    bool consume()
    {
        if (buffer.isEmpty())
        {
            cout << "Buffer is empty. Consumer waiting..." << endl;
            return false;
        }

        int item = buffer.front();
        buffer.pop();
        cout << "Consumed: " << item << " (Buffer size: " << buffer.size() << ")" << endl;
        return true;
    }

    // Switch between production and consumption mode
    void toggleMode()
    {
        producing = !producing;
    }

    bool isProducing() const
    {
        return producing;
    }
};

void simulateProducerConsumer(int items)
{
    Buffer buffer;
    SimpleRandom random;
    int producedCount = 0;
    int consumedCount = 0;

    cout << "Producer-Consumer Problem Simulation:" << endl;
    cout << "Buffer size: " << BUFFER_SIZE << ", Items to produce/consume: " << items << endl;

    // Simulate interleaved producer and consumer operations
    while (producedCount < items || consumedCount < items)
    {
        // Attempt to produce
        if (producedCount < items)
        {
            int item = random.next(1, 100);
            if (buffer.produce(item))
            {
                producedCount++;
                // Simulate processing time
                int processTime = random.next(1, 3);
                cout << "Producer processing for " << processTime << " time units..." << endl;
            }
        }

        // Attempt to consume
        if (consumedCount < items)
        {
            if (buffer.consume())
            {
                consumedCount++;
                // Simulate processing time
                int processTime = random.next(1, 3);
                cout << "Consumer processing for " << processTime << " time units..." << endl;
            }
        }
    }
}

int main()
{
    const int ITEMS_TO_PROCESS = 10;

    simulateProducerConsumer(ITEMS_TO_PROCESS);

    cout << "Simulation complete!" << endl;

    return 0;
}
